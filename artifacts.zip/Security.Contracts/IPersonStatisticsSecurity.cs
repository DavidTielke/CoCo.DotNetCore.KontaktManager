﻿using Bremacon.CorePersonManager.Logic.PersonManagement.Contracts;

namespace Security.Contracts
{
    public interface IPersonStatisticsSecurity : IPersonStatistics
    {
         
    }
}