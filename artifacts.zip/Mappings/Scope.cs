﻿namespace Mappings
{
    public enum Scope
    {
        Transient,
        Singleton
    }
}