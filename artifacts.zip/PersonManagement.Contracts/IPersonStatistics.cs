﻿namespace Bremacon.CorePersonManager.Logic.PersonManagement.Contracts
{
    public interface IPersonStatistics
    {
        PersonAgeStatistic GetAgeStatistic();
    }
}