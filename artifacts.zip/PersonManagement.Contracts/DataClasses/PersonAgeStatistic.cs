namespace Bremacon.CorePersonManager.Logic.PersonManagement.Contracts
{
    public class PersonAgeStatistic
    {
        public int ChildrenCount { get; set; }
        public int AdultsCount { get; set; }
    }
}